# bulutSozluk
Bulut Bilişim Uzmanlığı Mezuniyet Projesi
